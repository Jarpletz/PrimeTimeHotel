create trigger PAYMENTINFO_TRIGGER
    before insert
    on PAYMENTINFO
    for each row
BEGIN
    SELECT paymentinfo_id_seq.NEXTVAL
    INTO :NEW.id
    FROM DUAL;
END;
/

