create trigger ACCOUNT_TRIGGER
    before insert
    on ACCOUNTS
    for each row
BEGIN
    SELECT account_id_seq.NEXTVAL
    INTO :NEW.id
    FROM DUAL;
END;
/

