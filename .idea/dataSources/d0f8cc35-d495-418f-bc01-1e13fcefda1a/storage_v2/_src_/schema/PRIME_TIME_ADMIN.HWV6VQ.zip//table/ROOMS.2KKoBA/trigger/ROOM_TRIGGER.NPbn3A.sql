create trigger ROOM_TRIGGER
    before insert
    on ROOMS
    for each row
BEGIN
    SELECT room_id_seq.NEXTVAL
    INTO :NEW.id
    FROM DUAL;
END;
/

