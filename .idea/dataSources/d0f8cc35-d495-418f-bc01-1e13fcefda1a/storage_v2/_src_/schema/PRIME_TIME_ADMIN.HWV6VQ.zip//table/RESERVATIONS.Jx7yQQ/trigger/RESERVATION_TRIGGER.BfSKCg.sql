create trigger RESERVATION_TRIGGER
    before insert
    on RESERVATIONS
    for each row
BEGIN
    SELECT reservation_id_seq.NEXTVAL
    INTO :NEW.id
    FROM DUAL;
END;
/

