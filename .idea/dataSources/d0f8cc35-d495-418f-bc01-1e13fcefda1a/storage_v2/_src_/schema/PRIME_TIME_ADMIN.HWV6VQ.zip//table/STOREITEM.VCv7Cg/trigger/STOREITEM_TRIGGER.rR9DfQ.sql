create trigger STOREITEM_TRIGGER
    before insert
    on STOREITEM
    for each row
BEGIN
    SELECT storeitem_id_seq.NEXTVAL
    INTO :NEW.id
    FROM DUAL;
END;
/

